import './App.css';
import axios from 'axios';
import { useState, useEffect } from 'react'
import { DrinkCard } from './DrinkCard';





function App() {
  const [selectedDrink, setSelectedDrink] = useState(null)
  const [featuredDrinks, setFeaturedDrinks] = useState(null)

  function getDrinks() {
    const options = {
      method: 'GET',
      url: 'https://the-cocktail-db.p.rapidapi.com/popular.php',
      headers: {
        'X-RapidAPI-Key': 'c468c3f059mshbbf1657040b7881p1b02d9jsn95c2fe1561d1',
        'X-RapidAPI-Host': 'the-cocktail-db.p.rapidapi.com'
      }
    };
  
    axios.request(options).then(function (response) {
      console.log("providing drink data", response.data.drinks);
      setFeaturedDrinks(response.data.drinks);
    }).catch(function (error) {
      console.error(error);
    });
  }

  useEffect(() => {
    getDrinks()
  }, [])

  if (selectedDrink === null) {
    return (
      <div className="App">
        <main>
          <div>
            <h2 className='companyName' >paradise cocktails</h2>
          </div>
          <div>
            <h2 className='brownColor'>Featured Cocktails</h2>
          </div>
          <div className='drinkGrid'>
            {featuredDrinks && featuredDrinks.map((el) => {
              return (
                <div key={el.idDrink} className='drinkContainer'>
                  <img src={el.strDrinkThumb} className='drinkImg' alt={el.strDrink}></img>
                  <div className='drinkTxtContainer'>
                    <div className='flexColumn'>
                      <h4 className='brownColor flexCenter marginOff'>{el.strDrink}</h4>
                      <p className='brownColor lightWeight marginOff'>{el.strCategory}</p>
                    </div>
                    <button className='orangeButton' onClick={()=> setSelectedDrink(el)}>{"->"}</button>
                  </div>
                </div>)
            })}
          </div>
        </main>
      </div>
      );
  } else {
    return (
      <div className="App">
        <main>
          <div onClick={() => setSelectedDrink(null)}>
            <h2 className='companyName'>paradise cocktails</h2>
          </div>
          <div className='flexRow'>
            <img src={selectedDrink.strDrinkThumb} className='selectedImg'></img>
            <DrinkCard selectedDrink={selectedDrink}></DrinkCard>
          </div>
        </main>
      </div>
      );
  }
  
}

export default App;
