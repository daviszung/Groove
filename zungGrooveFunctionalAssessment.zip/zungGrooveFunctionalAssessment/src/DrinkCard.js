import { useEffect, useState } from "react"

export function DrinkCard({selectedDrink}) {
  console.log(selectedDrink)
  const [ingredients, setIngredients] = useState([])


  useEffect(() => {
    for (let i in selectedDrink) {
      if (i.substring(0, 13) === 'strIngredient' && selectedDrink[i] !== null) {
        setIngredients(oldArr => [...oldArr, <li className="brownColor">{selectedDrink[i]}</li>])
      }
    }
    console.log(ingredients)
  }, [selectedDrink])

  return (
    <div className="drinkCard">
      <div>
        <h1 className="brownColor">{selectedDrink.strDrink}</h1>
        <h4 className="brownColor">Ingredients</h4>
        <ul>
          {ingredients ? ingredients : null}
        </ul>
        <h4 className="brownColor">Instructions</h4>
        <p className="brownColor instructionsTxt">{selectedDrink.strInstructions}</p>
      </div>
    </div>
  )
}